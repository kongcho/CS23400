from detector_wrapper import DetectorWrapper

detector = DetectorWrapper()

success, ret = detector.detect()
